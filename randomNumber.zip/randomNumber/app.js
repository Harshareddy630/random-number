const express=require("express");
const { check, validationResult } = require('express-validator')
const ejs=require("ejs");
const bodyParser=require("body-parser");
const mongoose=require("mongoose");
const session=require("express-session");
var flash=require("connect-flash");
const passport=require("passport");
const passportLocalMongoose=require("passport-local-mongoose");
const app=express();
const findOrCreate = require('mongoose-findorcreate');

///////this is used to create sessions or each user
app.use(session({
	secret: 'this is my secret',
	resave: false,
	saveUninitialized: false,
}));

app.use(flash());

///now we are initializing the passport
app.use(passport.initialize());

app.use(passport.session());


mongoose.connect("mongodb://localhost:27017/Randomnumber",{ useNewUrlParser: true,useUnifiedTopology: true,useFindAndModify: false  });
mongoose.set("useCreateIndex",true);


const userSchema=new mongoose.Schema({
	username:String,
	password:String,
	googleId:String,
	username:String,
	secret:String
});


userSchema.plugin(passportLocalMongoose);
userSchema.plugin(findOrCreate);




const User=new mongoose.model("User",userSchema);



passport.use(User.createStrategy());

passport.serializeUser(function(user, done) {
	done(null, user.id);
});

passport.deserializeUser(function(id, done) {
	User.findById(id, function(err, user) {
		done(err, user);
	});
});





app.use(express.static("public"));
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:true}));




app.get("/login",function(req,res){

	var message=req.flash('message');
	var errormessage= req.flash().error;




	res.render("login",{message:message,error:errormessage});

});
app.get("/register",function(req,res){
	var message=req.flash('message');



	res.render("register",{message:message});


	

});


app.get("/",function(req,res){

	res.render("home");

});








app.post("/register",function(req,res){

	User.find({username:req.body.username},function(err,founduser){

		if (err) {
			console.log(err);
		}else{
			if (founduser.length > 0) {

				req.flash('message','User Exists.');
				res.redirect('/register');

			}else{

					User.register({username:req.body.username},req.body.password,function(err,user){
		if (err) {
			console.log(err);
			res.redirect("/register");
		}else{
			passport.authenticate("local")(req,res,function(){

				req.flash('message','User Registered. Please Login!');
				

				res.redirect("/login");
			})
		}

	})


			}
		}

	})







});



app.post("/login",function(req,res){

	const user=new User({

		username:req.body.username,
		password:req.body.password,
	});

	req.login(user,function(err){

		if (err) {
			console.log(err);
			res.redirect("/register");
		}else{


			passport.authenticate("local",{ failureRedirect: '/login',failureFlash:"Invalid username or password."})(req,res,function(){


		
	



				res.render("secret");


				

				
			});
		}
	});
});

app.get("/logout",function(req,res){

	req.logout();
	res.render("home");

});


app.post("/randomone", 

  function(req, res){
   let alerts = undefined
   const errors = validationResult(req)
  
   if(!errors.isEmpty()) {
         alerts = errors.array()
         res.render('secret',{alert:alerts})
   }else{
         
         if(req.body.num1 > Number.MAX_SAFE_INTEGER || req.body.num2 > Number.MAX_SAFE_INTEGER){
            alerts = [{msg : "The values should be in integer range"}]
            res.render('secret', {alert : alerts})
         }else if(req.body.num1 == '' || req.body.num2 == ''){
            alerts = [{msg : "Please enter both the values"}]
            res.render('secret', {alert : alerts})
         }else if(!Number.isInteger(Number(req.body.num1)) || !Number.isInteger(Number(req.body.num1))){
            alerts = [{msg : "The values should be of integer type"}]
            res.render('secret', {alert : alerts})
         }
         else if(Number(req.body.num1) >= Number(req.body.num2)){
            alerts = [{msg : "The first value should be less than the second value"}]
            res.render('secret', {alert : alerts}) 
         }else if(isNaN(Number(req.body.num1)) || isNaN(Number(req.body.num2))){
            alerts = [{msg : "Please enter only the number values"}]
            res.render('secret', {alert : alerts}) 
         }
         else{
            var rn = require('random-number');
            var options = {
                 min:  Number(req.body.num1),
                 max:  Number(req.body.num2),
                 integer: true
                }
            let result = undefined
            result = rn(options)
            res.render("secret", {random : result})
         }
      }
})



app.listen(3000,function(req,res){

	console.log("server is started and running on port 3000");

});






